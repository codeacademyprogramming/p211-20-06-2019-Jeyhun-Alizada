"use strict";
$(document).ready(function() {
  $(".main img").attr(
    "src",
    $(".listImg")
      .first()
      .attr("src")
  );
  $(".mainP").text(
    $(".listLi")
      .first("p")
      .text()
  );
  $(".listLi").click(function(e) {
    e.preventDefault();
    const newSrc = $(this)
      .find("img")
      .attr("src");
    $(".main img").attr("src", newSrc);
    const newP = $(this)
      .find("p")
      .text();
    $(".mainP").text(newP);
  });
  $(".fas.fa-trash").click(function() {
    $(this)
      .parents("li")
      .remove();
  });
  let checkboxIn;
  let myStart = function() {
    let a = 0;
    checkboxIn = setInterval(function() {
      a++;
      if (a <= 7) {
        let changeSrc = a + ".jpg";
        let newP = "Atiye "+ a; 
        $(".main img").attr("src", changeSrc);
        $(".mainP").text(newP);
      } else {
        a = 0;
      }
    }, 1000);
  };
  let myStop = function() {
    clearInterval(checkboxIn);
  };
  $(".checkbox").change(function() {
    if ($(".checkbox").is(":checked")) {
      myStart();
    } else {
      myStop();
    }
  });
});
